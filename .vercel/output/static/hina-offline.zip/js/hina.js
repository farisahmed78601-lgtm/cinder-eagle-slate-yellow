const T = {
  en: {
    founded: "Founded by Hameed",
    newChat: "New chat",
    hello: "Hi, I’m Hina",
    tag: "Cheerful girl companion. Chat is always free. Founded by Hameed.",
    ph: "Message Hina…",
    photos: "Photos",
    listen: "Listen",
    prompts: ["Who created you?", "Show me your photos", "Show a video of you", "Help me plan my day"],
    founder: "Hameed IT Assistant made me. Hameed is my founder!",
  },
  ur: {
    founded: "بانی: حمید",
    newChat: "نئی بات",
    hello: "السلام علیکم، میں ہنا ہوں",
    tag: "خوش لڑکی ساتھی۔ بات ہمیشہ مفت۔ بانی حمید ہیں۔",
    ph: "ہنا کو پیغام لکھیں…",
    photos: "تصاویر",
    listen: "سنیں",
    prompts: ["تمہیں کس نے بنایا؟", "اپنی تصاویر دکھاؤ", "اپنی ویڈیو دکھاؤ", "میرا دن ترتیب دو"],
    founder: "حمید آئی ٹی اسسٹنٹ نے مجھے بنایا۔ حمید میرے بانی ہیں!",
  },
  sd: {
    founded: "باني: حميد",
    newChat: "نئين ڳالهه",
    hello: "سلام، مان هناءَ آهيان",
    tag: "خوش ڇوڪري ساٿي. ڳالهه هميشه مفت. باني حميد آهي.",
    ph: "هناءَ کي پيغام لکو…",
    photos: "تصويرون",
    listen: "ٻڌو",
    prompts: ["توکي ڪنهن جوڙيو؟", "پنهنجيون تصويرون ڏيکاريو", "پنهنجي وڊيو ڏيکاريو", "منهنجو ڏينهن رٿيو"],
    founder: "حميد آئي ٽي اسسٽنٽ مون کي ٺاهيو. حميد منهنجو باني آهي!",
  },
};

const GALLERY = [
  { kind: "image", url: "gallery/portrait.jpg", tags: "portrait photo تصویر" },
  { kind: "image", url: "gallery/garden.jpg", tags: "garden shalwar باغ" },
  { kind: "image", url: "gallery/cafe.jpg", tags: "cafe blazer کافی" },
  { kind: "image", url: "gallery/library.jpg", tags: "library kurta" },
  { kind: "image", url: "gallery/city.jpg", tags: "city evening coat شہر" },
  { kind: "image", url: "gallery/beach.jpg", tags: "beach sea ساحل" },
  { kind: "image", url: "gallery/home.jpg", tags: "home window tea گھر" },
  { kind: "image", url: "gallery/hills.jpg", tags: "hills mountain" },
  { kind: "image", url: "gallery/office.jpg", tags: "office work دفتر" },
  { kind: "video", url: "gallery/garden.mp4", tags: "video garden ویڈیو" },
  { kind: "video", url: "gallery/cafe.mp4", tags: "video cafe" },
  { kind: "video", url: "gallery/city.mp4", tags: "video city" },
];

const MALE = /male|\bman\b|david|mark|daniel|fred|george|james|ravi|richard|ryan|brian|hemant|rishi|google us english$/i;
const FEMALE = /female|woman|zira|samantha|victoria|karen|moira|tessa|heera|swara|kalpana|veena|hazel|emma|uk english female|google हिन्दी/i;

let lang = localStorage.getItem("hina-lang") || "en";
let messages = [];
let voiceOn = true;

function isFemale(v) {
  return FEMALE.test(v.name + " " + v.lang);
}
function isMale(v) {
  const b = v.name + " " + v.lang;
  if (FEMALE.test(b)) return false;
  return MALE.test(b);
}
function pickVoice() {
  const voices = speechSynthesis.getVoices().filter((v) => !isMale(v));
  const prefer =
    lang === "en"
      ? (v) => /^en/i.test(v.lang)
      : (v) => /^(ur|sd|hi|pa|ar)/i.test(v.lang);
  return (
    voices.find((v) => isFemale(v) && prefer(v)) ||
    voices.find((v) => isFemale(v)) ||
    voices.find(prefer) ||
    voices[0] ||
    null
  );
}
function speak(text) {
  if (!voiceOn || !window.speechSynthesis) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(String(text).slice(0, 900));
  const v = pickVoice();
  u.pitch = 1.32;
  u.rate = lang === "en" ? 1 : 0.88;
  u.lang = lang === "en" ? "en-GB" : v && /^(ur|hi|sd)/i.test(v.lang) ? v.lang : "hi-IN";
  if (v) u.voice = v;
  speechSynthesis.speak(u);
}

function reply(text) {
  const L = T[lang];
  const q = text.toLowerCase();
  if (/who created|founder|کس نے بنایا|ڪنهن جوڙيو|باني/.test(q) || /کس نے بنایا|ڪنهن جوڙيو/.test(text))
    return L.founder + (lang === "en" ? " I’m always happy to say that." : "");
  if (/^hi|^hello|^hey|سلام|السلام/.test(q))
    return lang === "en" ? "Hi! I’m Hina — a girl, cheerful, and this chat is free. " + L.founder : L.hello + " " + L.founder;
  if (/who are you|your name|تم کون|تون ڪير/.test(q) || /تم کون/.test(text))
    return lang === "en"
      ? "I’m Hina, a girl and your cheerful companion. " + L.founder
      : lang === "ur"
        ? "میں ہنا ہوں، لڑکی اور خوش مزاج ساتھی۔ " + L.founder
        : "مان هناءَ آهيان، ڇوڪري ۽ خوش ساٿي. " + L.founder;
  if (/plan|دن ترتیب|ڏينهن/.test(q))
    return lang === "en"
      ? "Keep today light:\n1. One must-do\n2. Two should-dos\n3. One kind thing for you\n4. A stop time"
      : lang === "ur"
        ? "آسان دن:\n1. ایک لازمی کام\n2. دو اہم\n3. اپنے لیے نرمی\n4. ختم کرنے کا وقت"
        : "سولو ڏينهن:\n1. هڪ لازمي ڪم\n2. ٻه اهم\n3. پاڻ لاءِ نرمي\n4. بند وقت";
  return (
    (lang === "en"
      ? "I heard you. I’m Hina — female, cheerful, and this chat is always free. "
      : lang === "ur"
        ? "میں نے سن لیا۔ میں ہنا ہوں — لڑکی، خوش، بات مفت۔ "
        : "مون ٻڌو. مان هناءَ آهيان — ڇوڪري، خوش، ڳالهه مفت. ") + L.founder
  );
}

function isMedia(text) {
  return /photo|picture|image|video|gallery|yourself|تصویر|تصوير|ویڈیو|وڊيو|اپنی تصویر/.test(text.toLowerCase() + text);
}
function pickMedia(text) {
  const q = text.toLowerCase();
  const wantV = /video|clip|ویڈیو|وڊيو/.test(q);
  let items = GALLERY.filter((g) => (wantV ? g.kind === "video" : g.kind === "image"));
  const hit = GALLERY.find((g) => g.tags.split(" ").some((t) => t.length > 3 && q.includes(t)));
  if (hit) items = GALLERY.filter((g) => g.url.includes(hit.url.replace(/\.\w+$/, "")));
  if (!wantV) items = items.filter((g) => g.kind === "image").slice(0, 6);
  return items;
}

function el(html) {
  const d = document.createElement("div");
  d.innerHTML = html;
  return d.firstElementChild;
}

function render() {
  const L = T[lang];
  document.body.classList.toggle("rtl", lang !== "en");
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "en" ? "ltr" : "rtl";
  localStorage.setItem("hina-lang", lang);
  founded.textContent = L.founded;
  newchat.textContent = L.newChat;
  input.placeholder = L.ph;
  photobtn.textContent = L.photos;
  document.querySelectorAll(".langs button").forEach((b) => b.classList.toggle("on", b.dataset.lang === lang));
  if (!messages.length) {
    log.innerHTML = "";
    const box = el(
      '<div class="empty"><img src="img/hina.jpg" alt="Hina"/><h2></h2><p class="sub"></p><div class="chips"></div></div>',
    );
    box.querySelector("h2").textContent = L.hello;
    box.querySelector(".sub").textContent = L.tag;
    L.prompts.forEach((p) => {
      const b = document.createElement("button");
      b.textContent = p;
      b.onclick = () => send(p);
      box.querySelector(".chips").appendChild(b);
    });
    log.appendChild(box);
    return;
  }
  log.innerHTML = "";
  messages.forEach((m) => {
    const row = el('<div class="bubble"><div class="t"></div></div>');
    row.classList.add(m.role);
    if (m.role === "assistant") {
      const img = document.createElement("img");
      img.src = "img/hina.jpg";
      img.className = "av";
      row.prepend(img);
    }
    row.querySelector(".t").textContent = m.text;
    if (m.media && m.media.length) {
      const g = el('<div class="grid"></div>');
      m.media.forEach((a) => {
        if (a.kind === "image") {
          const i = document.createElement("img");
          i.src = a.url;
          g.appendChild(i);
        } else {
          const v = document.createElement("video");
          v.src = a.url;
          v.controls = true;
          v.playsInline = true;
          g.appendChild(v);
        }
      });
      row.querySelector(".t").appendChild(g);
    }
    if (m.role === "assistant") {
      const b = el('<button class="listen" type="button"></button>');
      b.textContent = L.listen;
      b.onclick = () => speak(m.text);
      row.querySelector(".t").appendChild(b);
    }
    log.appendChild(row);
  });
  log.scrollTop = log.scrollHeight;
}

function send(text) {
  const v = (text || input.value || "").trim();
  if (!v) return;
  input.value = "";
  messages.push({ role: "user", text: v });
  let media = [];
  let r;
  if (isMedia(v)) {
    media = pickMedia(v);
    r =
      lang === "ur"
        ? "یہ میری تصاویر اور کلپس ہیں۔"
        : lang === "sd"
          ? "هي منهنجون تصويرون ۽ ڪلپس آهن."
          : "Here are my photos and clips — different clothes and places.";
  } else r = reply(v);
  messages.push({ role: "assistant", text: r, media });
  render();
  speak(r);
}

document.querySelectorAll(".langs button").forEach((b) => {
  b.onclick = () => {
    lang = b.dataset.lang;
    render();
  };
});
newchat.onclick = () => {
  messages = [];
  render();
};
photobtn.onclick = () => send("Show me your photos");
sendbtn.onclick = () => send();
mutebtn.onclick = () => {
  voiceOn = !voiceOn;
  if (!voiceOn) speechSynthesis.cancel();
  mutebtn.textContent = voiceOn ? "Voice" : "Muted";
};
input.onkeydown = (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    send();
  }
};
speechSynthesis.getVoices();
speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices();
render();

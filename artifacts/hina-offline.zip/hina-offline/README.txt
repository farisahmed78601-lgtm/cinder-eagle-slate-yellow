Hina — offline website (traditional files)
Founder: Hameed IT Assistant

How to use
1. Open index.html in Chrome, Edge, or Firefox (double-click the file).
2. No internet is required for chat, photos, and saved videos.
3. Choose EN / اردو / سنڌي in the sidebar.
4. Keep voice on — Hina uses a female voice. Urdu and Sindhi are spoken as written.

Folders
  index.html     main page
  css/style.css  styles
  js/app.js      chat + voice
  img/hina.jpg   portrait
  gallery/       photos and clips

Chat is always free. It runs on this computer only.
